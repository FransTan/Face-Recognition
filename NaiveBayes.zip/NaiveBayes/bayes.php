<?php
class Bayes
{
  private $pegawai = "data.json";

  function sumTrue()
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach($hasil as $hasil)
    {
      if($hasil['status'] == 1){
        $t += 1;
      }
    }
    return $t;
  }

  function sumFalse()
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach($hasil as $hasil)
    {
      if($hasil['status'] == 0){
        $t += 1;
      }
    }
    return $t;
  }

  function sumData()
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);
    return count($hasil);
  }

  function probUmur($umur,$status)
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach ($hasil as $hasil) {
      if($hasil['umur'] == $umur && $hasil['status'] == $status){
        $t += 1;
      }
    }
    return $t;
  }

  function probTinggi($tinggi,$status)
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach ($hasil as $hasil) {
      if($hasil['tinggi'] == $tinggi && $hasil['status'] == $status){
        $t += 1;
      }
    }
    return $t;
  }

  function probBeratB($bb,$status)
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach ($hasil as $hasil) {
      if($hasil['berat_badan'] == $bb && $hasil['status'] == $status){
        $t += 1;
      }
    }
    return $t;
  }

  function probPendidikan($pendidikan,$status)
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach ($hasil as $hasil) {
      if($hasil['pendidikan'] == $pendidikan && $hasil['status'] == $status){
        $t += 1;
      }
    }
    return $t;
  }

  function probKesehatan($kesehatan,$status)
  {
    $data = file_get_contents($this->pegawai);
    $hasil = json_decode($data,true);

    $t = 0;
    foreach ($hasil as $hasil) {
      if($hasil['kesehatan'] == $kesehatan && $hasil['status'] == $status){
        $t += 1;
      }
    }
    return $t;
  }

  /*=================================================================
  Keterangan parameter :
  $sT   : jumlah data yang bernilai true ( sumTrue )
  $sF   : jumlah data yang bernilai false ( sumFalse )
  $sD   : jumlah data pada data latih ( sumData )
  $pU   : jumlah probabilitas umur ( probUmur )
  $pT   : jumlah probabilitas tinggi ( probTinggi )
  $pBB  : jumlah probabilitas berat badan ( probBB )
  $pK   : jumlah probabilitas kesehatan ( probKesehatan )
  $pP   : jumlah probabilitas pendidikan (probPendidikan )
  ==================================================================*/

  //penambahan nilai 1 adalah untuk laplacian correction
  function hasilTrue($sT = 0 , $sD = 0 , $pU = 0 ,$pT = 0, $pBB = 0,$pK = 0, $pP = 0)
  {
    $paTrue = $sT / $sD;
    $p1 = ($pU + 1) / ($sT + 1);
    $p2 = ($pT + 1) / ($sT + 1);
    $p3 = ($pBB + 1) / ($sT + 1);
    $p4 = ($pK + 1) / ($sT + 1);
    $p5 = ($pP + 1) / ($sT + 1);
    $hsl = $paTrue * $p1 * $p2 * $p3 * $p4 * $p5;
    return $hsl;
  }

  //penambahan nilai 1 adalah untuk laplacian correction
  function hasilFalse($sF = 0 , $sD = 0 , $pU = 0 ,$pT = 0, $pBB = 0,$pK = 0, $pP = 0)
  {
    $paFalse = $sF / $sD;
    $p1 = ($pU + 1) / ($sF + 1);
    $p2 = ($pT + 1) / ($sF + 1);
    $p3 = ($pBB + 1) / ($sF + 1);
    $p4 = ($pK + 1) / ($sF + 1);
    $p5 = ($pP + 1) / ($sF + 1);
    $hsl = $paFalse * $p1 * $p2 * $p3 * $p4 * $p5;
    return $hsl;
  }

  function perbandingan($pATrue,$pAFalse)
  {
    if($pATrue > $pAFalse){
      $stt = "DITERIMA";
      $hitung = ($pATrue / ($pATrue + $pAFalse)) * 100;
      $diterima = 100 - $hitung;
    }elseif($pAFalse > $pATrue)
    {
      $stt = "DITOLAK";
      $hitung = ($pAFalse / ($pAFalse + $pATrue)) * 100;
      $diterima = 100 - $hitung;
    }

    $hsl = array($stt,$hitung,$diterima);
    return $hsl;
  }
  //=================================================================
}

?>
