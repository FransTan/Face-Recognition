<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" type="image/x-icon" href="assets/img/logo.png" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />

  <!-- font awsome -->
  <link rel="stylesheet" href="assets/css/fontawesome.css" />
  <link rel="stylesheet" href="assets/css/brands.css" />
  <link rel="stylesheet" href="assets/css/solid.css" />
  <link rel="stylesheet" href="assets/css/gaya.css">

  <!-- google font -->
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,700&display=swap" rel="stylesheet">

  <title>Naive Bayes</title>
</head>

<body>

  <nav class="navbar navbar-expand-lg fixed-top navbar-light bg-light static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">
        <img src="assets/img/logo.png" alt="" width=50 height=50>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Naive Bayes
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" href="data_simulasi.php">Data Latih</a>
          </li> -->
        </ul>
      </div>
    </div>
  </nav>

  <div class="container" style='margin-top:90px'>

    <div class="row">
      <div class="col-12 mt-4">
        <h3 class="tebal">Prediksi Diterimanya Lamaran Pekerjaan Pada PT Alam Sejahtera :</h3>
      </div>

      <div class="col-6">
        <form method="POST" class="mt-3">

          <div class="form-group">
            <label for="umur">Umur :</label>
            <input type="number" name="umur" id="umur" value="$i" class="form-control" placeholder="-- Masukkan Umur Anda --" required>
          </div>

          <div class="form-group">
            <label for="tinggi">Tinggi Badan :</label>
            <select name="tinggi" id="tinggi" class="form-control selBox" required="required">
              <option value="" disabled selected>-- Masukkan Tinggi Anda --</option>
              <option value="kt">Kurang Tinggi</option>
              <option value="ideal">Ideal</option>
              <option value="st">Sangat Tinggi</option>
            </select>
          </div>

          <div class="form-group">
            <label for="umur">Postur Badan :</label>
            <select name="beratB" id="beratB" class="form-control selBox" required="required">
              <option value="" disabled selected>-- Masukkan Postur Badan Anda --</option>
              <option value="kurus">Kurus</option>
              <option value="ideal">Ideal</option>
              <option value="tambun">Tambun</option>
            </select>
          </div>

          <div class="form-group">
            <label for="umur">Status Kesehatan :</label>
            <select name="kesehatan" id="kesehatan" class="form-control selBox" required="required">
              <option value="" disabled selected>-- Masukkan Status Kesehatan Anda --</option>
              <option value="sehat">Sehat</option>
              <option value="tidak_sehat">Tidak Sehat</option>
            </select>
          </div>

          <div class="form-group">
            <label for="umur">Pendidikan :</label>
            <select name="pendidikan" id="pendidikan" class="form-control selBox" required="required">
              <option value="" disabled selected>-- Masukkan Pendidikan Anda --</option>
              <option value="sma">SMA</option>
              <option value="smk">SMK</option>
              <option value="s1">S1</option>
            </select>
          </div>

          <div class="form-group">
            <input type="submit" value="Submit" class="btn btn-primary mt-3" id="dor" onclick="return simulasi()" />
          </div>

        </form>
      </div>
    </div>

    <div class="row">
      <div class="col-12 mt-5 mb-5">
        <div id="hasilSIM" style="margin-bottom:30px;">
          <!-- Data Simulasi Predksi Diisi Disini -->
        </div>
      </div>
    </div>

  </div>


  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="assets/js/jquery.js"></script>
  <script src="assets/jspopper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>

  <!-- validasi -->
  <script>
    $(document).ready(function() {
      $('.toggle').click(function() {
        $('ul').toggleClass('active');
      });
    });
  </script>

  <script>
    function simulasi() {
      var umur = $("#umur").val();
      var tinggi_badan = $("#tinggi").val();
      var berat_badan = $("#beratB").val();
      var status_kesehatan = $("#kesehatan").val();
      var pendidikan = $("#pendidikan").val();

      //validasi
      var um = document.getElementById("umur").value;
      var tb = document.getElementById("tinggi");
      var bb = document.getElementById("beratB");
      var sk = document.getElementById("kesehatan");
      var pp = document.getElementById("pendidikan");

      if (um == "") {
        alert("Umur Tidak Boleh Kosong dan Harus Angka");
        return false;
      }

      if (tb.selectedIndex == 0) {
        alert("Tinggi Badan Tidak Boleh Kosong");
        return false;
      }

      if (bb.selectedIndex == 0) {
        alert("Berat Badan Tidak Boleh Kosong");
        return false;
      }

      if (sk.selectedIndex == 0) {
        alert("Status Kesehatan Tidak Boleh Kosong");
        return false;
      }

      if (pp.selectedIndex == 0) {
        alert("Pendidikan Tidak Boleh Kosong");
        return false;
      }

      //batas validasi

      $.ajax({
        url: 'simulasi.php',
        type: 'POST',
        dataType: 'html',
        data: {
          umur: umur,
          tinggi_badan: tinggi_badan,
          berat_badan: berat_badan,
          status_kesehatan: status_kesehatan,
          pendidikan: pendidikan
        },
        success: function(data) {
          document.getElementById("hasilSIM").innerHTML = data;
        },
      });

      return false;

    }
  </script>

</body>

</html>